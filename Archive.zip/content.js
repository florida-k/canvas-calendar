console.log("Canvas Calendar Power Tool loaded!");


// --------------------------------------------------
// Chrome local storage
// --------------------------------------------------

function getStorageKey(assignment) {
  return `powerTool_${assignment.course_id}_${assignment.id}`;
}



async function getSavedMetadata(assignment) {
  const key = getStorageKey(assignment);

  try {
    const response = await chrome.runtime.sendMessage({
      type: "MYCAL_GET_METADATA",
      courseId: String(assignment.course_id),
      assignmentId: String(assignment.id)
    });

    if (response?.ok && response.data) {
      const backendData = response.data;

      // Convert Spring Boot's format into the format
      // your existing MyCal editor expects.
      const metadata = {
        priority: backendData.priority?.toLowerCase() || null,
        estimatedTime: backendData.estimatedMinutes != null
          ? formatEstimatedTime(backendData.estimatedMinutes)
          : null,
        notes: backendData.notes || ""
      };

      // Keep Chrome storage synchronized with PostgreSQL.
      await chrome.storage.local.set({
        [key]: metadata
      });

      return metadata;
    }

    if (response?.ok && response.data === null) {
      // No database record yet. Preserve older local plans.
      const local = await chrome.storage.local.get(key);
      return local[key] || null;
    }

    console.warn("MyCal backend loading failed:", response?.error);

  } catch (error) {
    console.warn("MyCal backend unavailable:", error.message);
  }

  // Fallback if Spring Boot is offline.
  const local = await chrome.storage.local.get(key);
  return local[key] || null;
}

// Convert minutes from PostgreSQL to MyCal's display format.
function formatEstimatedTime(minutes) {
  const value = Number(minutes);

  if (!Number.isFinite(value) || value < 0) return null;

  if (value >= 60 && value % 60 === 0) {
    return `${value / 60}h`;
  }

  return `${value}m`;
}



async function saveMetadata(assignment, metadata) {
  const key = getStorageKey(assignment);

  await chrome.storage.local.set({
    [key]: metadata
  });

  console.log(
    "Saved Power Tool metadata:",
    key,
    metadata
  );
}


// --------------------------------------------------
// Load real Canvas assignments through Canvas API
// --------------------------------------------------

async function loadCanvasAssignments() {

  const coursesResponse = await fetch(
    "/api/v1/courses?enrollment_state=active&per_page=100",
    {
      credentials: "include"
    }
  );


  if (!coursesResponse.ok) {
    throw new Error(
      `Failed to load courses: ${coursesResponse.status}`
    );
  }


  const courses =
    await coursesResponse.json();

  console.log(
    "Canvas courses:",
    courses
  );


  // Get assignments for every active course
  const requests =
    courses.map(async (course) => {

      const response = await fetch(
        `/api/v1/courses/${course.id}/assignments?per_page=100`,
        {
          credentials: "include"
        }
      );


      if (!response.ok) {

        console.warn(
          `Could not load assignments for ${course.name}`
        );

        return [];
      }


      const assignments =
        await response.json();


      return assignments.map(
        (assignment) => ({
          ...assignment,

          // Keep course information
          // with each assignment
          course_id: course.id,
          course_name: course.name
        })
      );
    });


  const assignmentsByCourse =
    await Promise.all(requests);


  return assignmentsByCourse.flat();
}


// --------------------------------------------------
// Extract Canvas course ID from calendar DOM event
// --------------------------------------------------

function getCourseIdFromEvent(event) {

  const courseClass =
    [...event.classList].find(
      (className) =>
        className.startsWith(
          "group_course_"
        )
    );


  if (!courseClass) {
    return null;
  }


  return courseClass.replace(
    "group_course_",
    ""
  );
}


// --------------------------------------------------
// Power Tool assignment editor
// --------------------------------------------------

function openPowerToolEditor(
  event,
  assignment,
  metadata
) {

  // Remove an existing editor
  document
    .querySelector(
      ".power-tool-editor"
    )
    ?.remove();


  // --------------------------------------------------
  // Format Canvas due date
  // --------------------------------------------------

  let dueDateText =
    "No due date";


  if (assignment.due_at) {

    const dueDate =
      new Date(
        assignment.due_at
      );


    dueDateText =
      dueDate.toLocaleString(
        [],
        {
          month: "short",
          day: "numeric",
          hour: "numeric",
          minute: "2-digit"
        }
      );
  }


  // --------------------------------------------------
  // Parse existing estimated time
  //
  // "2h"  -> 2 + Hours
  // "45m" -> 45 + Minutes
  // --------------------------------------------------

  let initialTimeValue = "";
  let initialTimeUnit = "hours";


  const timeMatch =
    metadata.estimatedTime
      ?.match(
        /^([\d.]+)(h|m)$/
      );


  if (timeMatch) {

    initialTimeValue =
      timeMatch[1];


    initialTimeUnit =
      timeMatch[2] === "m"
        ? "minutes"
        : "hours";
  }


  // --------------------------------------------------
  // Create editor
  // --------------------------------------------------

  const editor =
    document.createElement(
      "div"
    );


  editor.className =
    "power-tool-editor";


  editor.innerHTML = `
    <div style="
      position: fixed;
      top: 120px;
      right: 30px;
      width: 330px;
      background: white;
      border: 1px solid #ddd;
      border-radius: 12px;
      padding: 20px;
      z-index: 99999;
      box-shadow: 0 6px 22px rgba(0,0,0,0.18);
      font-family: Arial, sans-serif;
    ">

      <!-- HEADER -->

      <div style="
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 14px;
      ">

        <div style="
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 1px;
          color: #777;
        ">
          CANVAS POWER TOOL
        </div>

        <button
          id="powerToolClose"
          type="button"
          style="
            border: none;
            background: transparent;
            font-size: 21px;
            line-height: 1;
            color: #777;
            cursor: pointer;
            padding: 2px 5px;
          "
        >
          ×
        </button>

      </div>


      <!-- CANVAS ASSIGNMENT INFORMATION -->

      <h3 style="
        margin: 0 0 6px 0;
        font-size: 18px;
        line-height: 1.3;
      ">
        ${assignment.name}
      </h3>

      <div style="
        font-size: 13px;
        color: #666;
        margin-bottom: 4px;
      ">
        ${assignment.course_name}
      </div>

      <div style="
        font-size: 13px;
        color: #777;
        margin-bottom: 18px;
      ">
        Due ${dueDateText}
      </div>


      <hr style="
        border: none;
        border-top: 1px solid #eee;
        margin: 0 0 18px 0;
      ">


      <!-- PRIORITY -->

      <div style="
        display: block;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
      ">
        PRIORITY
      </div>


      <div
        id="powerToolPriorityButtons"
        style="
          display: flex;
          gap: 8px;
          margin-bottom: 20px;
        "
      >

        <button
          type="button"
          data-priority="low"
          style="
            flex: 1;
            padding: 8px 5px;
            border-radius: 7px;
            cursor: pointer;
            background: white;
          "
        >
          🟢 Low
        </button>


        <button
          type="button"
          data-priority="medium"
          style="
            flex: 1;
            padding: 8px 5px;
            border-radius: 7px;
            cursor: pointer;
            background: white;
          "
        >
          🟡 Medium
        </button>


        <button
          type="button"
          data-priority="high"
          style="
            flex: 1;
            padding: 8px 5px;
            border-radius: 7px;
            cursor: pointer;
            background: white;
          "
        >
          🔴 High
        </button>

      </div>


      <!-- ESTIMATED TIME -->

      <div style="
        display: block;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
      ">
        ESTIMATED TIME
      </div>


      <div style="
        display: flex;
        gap: 8px;
        margin-bottom: 20px;
      ">

        <input
          id="powerToolTime"
          type="number"
          min="0"
          step="0.5"
          placeholder="2"
          style="
            width: 35%;
            box-sizing: border-box;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
          "
        />


        <select
          id="powerToolTimeUnit"
          style="
            flex: 1;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
            background: white;
          "
        >

          <option value="minutes">
            Minutes
          </option>

          <option value="hours">
            Hours
          </option>

        </select>

      </div>


      <!-- ACTIONS -->

      <div style="
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      ">

        <button
          id="powerToolCancel"
          type="button"
          style="
            padding: 7px 13px;
            cursor: pointer;
          "
        >
          Cancel
        </button>


        <button
          id="powerToolSave"
          type="button"
          style="
            padding: 7px 15px;
            cursor: pointer;
            font-weight: 600;
          "
        >
          Save
        </button>

      </div>

    </div>
  `;


  document.body.appendChild(
    editor
  );


  // --------------------------------------------------
  // Current priority
  // --------------------------------------------------

  let selectedPriority =
    metadata.priority ||
    "medium";


  // --------------------------------------------------
  // Estimated time inputs
  // --------------------------------------------------

  const timeInput =
    editor.querySelector(
      "#powerToolTime"
    );


  const timeUnitInput =
    editor.querySelector(
      "#powerToolTimeUnit"
    );


  timeInput.value =
    initialTimeValue;


  timeUnitInput.value =
    initialTimeUnit;


  // --------------------------------------------------
  // Priority buttons
  // --------------------------------------------------

  const priorityButtons =
    editor.querySelectorAll(
      "[data-priority]"
    );


  function updatePriorityButtons() {

    priorityButtons.forEach(
      (button) => {

        const isSelected =
          button.dataset.priority ===
          selectedPriority;


        if (isSelected) {

          button.style.border =
            "2px solid #444";

          button.style.fontWeight =
            "700";

          button.style.background =
            "#f5f5f5";

        } else {

          button.style.border =
            "1px solid #ccc";

          button.style.fontWeight =
            "400";

          button.style.background =
            "white";
        }

      }
    );
  }


  // Highlight saved priority
  updatePriorityButtons();


  // Change priority when clicked
  priorityButtons.forEach(
    (button) => {

      button.addEventListener(
        "click",
        () => {

          selectedPriority =
            button.dataset.priority;

          updatePriorityButtons();
        }
      );

    }
  );


  // --------------------------------------------------
  // Close
  // --------------------------------------------------

  editor
    .querySelector(
      "#powerToolClose"
    )
    .addEventListener(
      "click",
      () => {

        editor.remove();

      }
    );


  // --------------------------------------------------
  // Cancel
  // --------------------------------------------------

  editor
    .querySelector(
      "#powerToolCancel"
    )
    .addEventListener(
      "click",
      () => {

        editor.remove();

      }
    );


  // --------------------------------------------------
  // Save
  // --------------------------------------------------

  editor
    .querySelector(
      "#powerToolSave"
    )
    .addEventListener(
      "click",
      async () => {

        const newPriority =
          selectedPriority;


        const timeValue =
          timeInput.value;


        const timeUnit =
          timeUnitInput.value;


        // Don't save an empty estimated time
        if (!timeValue) {

          alert(
            "Please enter an estimated time."
          );

          return;
        }


        // Convert UI value back into our
        // existing compact storage format.
        //
        // 2 + Hours   -> "2h"
        // 45 + Minutes -> "45m"

        const newTime =
          timeUnit === "minutes"
            ? `${timeValue}m`
            : `${timeValue}h`;


        // Persist metadata
        await saveMetadata(
          assignment,
          {
            priority:
              newPriority,

            estimatedTime:
              newTime
          }
        );


        // Sync with the local Spring Boot backend (Chrome storage remains the fallback).
        // The backend stores time in whole minutes and priority in uppercase.
        const estimatedMinutes = Math.round(Number(timeValue) * (timeUnit === "hours" ? 60 : 1));
        try {
          const result = await chrome.runtime.sendMessage({
            type: "MYCAL_SAVE_METADATA",
            courseId: String(assignment.course_id),
            assignmentId: String(assignment.id),
            metadata: {
              priority: newPriority.toUpperCase(),
              estimatedMinutes,
              notes: metadata.notes || null
            }
          });
          if (!result?.ok) {
            console.warn("MyCal backend unavailable; saved locally:", result?.error);
          } else {
            console.log("MyCal saved to PostgreSQL:", result.data);
          }
        } catch (error) {
          console.warn("MyCal backend unavailable; saved locally:", error);
        }

        // Update current metadata object
        metadata.priority =
          newPriority;

        metadata.estimatedTime =
          newTime;


        // --------------------------------------------------
        // Update calendar badge immediately
        // --------------------------------------------------

        const badge =
          event.querySelector(
            ".power-tool-badge"
          );


        const priorityIcons = {
          high: "🔴",
          medium: "🟡",
          low: "🟢"
        };


        if (badge) {
          badge.textContent = `${priorityIcons[newPriority]} ${newPriority.toUpperCase()} · ⏱ ${newTime}`;
          badge.hidden = false;
        }


        editor.remove();
      }
    );
}


// Canvas event matching: prefer an actual assignment ID from the event/link.
// A title is NOT a unique identifier. If no ID exists, only use a title when
// it identifies exactly one API assignment within the course.
function decodeCanvasText(value) {
  const element = document.createElement("textarea");
  element.innerHTML = value || "";
  return element.value.replace(/\s+/g, " ").trim();
}


function getAssignmentIdFromEvent(event) {
  const nodes = [
    event,
    ...event.querySelectorAll("*")
  ];

  for (const node of nodes) {
    // Check Canvas data attributes
    for (const attr of [
      "data-assignment-id",
      "data-assignment_id",
      "data-assignmentid"
    ]) {
      const value = node.getAttribute(attr);

      if (value && /^\d+$/.test(value)) {
        return value;
      }
    }

    // Check links to actual Canvas assignments
    for (const attr of ["href", "data-url"]) {
      const value = node.getAttribute(attr) || "";

      const match = value.match(
        /\/assignments\/(\d+)(?:[/?#]|$)/
      );

      if (match) {
        return match[1];
      }
    }
  }

  return null;
}


function matchCanvasAssignment(event, assignments) {
  const courseId = getCourseIdFromEvent(event);
  if (!courseId) return null;
  const inCourse = assignments.filter(a => String(a.course_id) === String(courseId));
  const assignmentId = getAssignmentIdFromEvent(event);
  if (assignmentId) {
    return inCourse.find(a => String(a.id) === assignmentId) || null;
  }
  // Compatibility fallback for Canvas event DOMs without exposed assignment IDs.
  const title = decodeCanvasText(event.getAttribute("title") || event.querySelector(".fc-title")?.textContent);
  const candidates = inCourse.filter(a => decodeCanvasText(a.name) === title);
  if (candidates.length === 1) return candidates[0];
  if (candidates.length > 1) console.warn("MyCal: ambiguous assignment title; skipping", title);
  return null;
}

let cachedAssignments = null;
let calendarEnhancementRunning = false;
let calendarRefreshTimer = null;

async function enhanceCalendar() {
  if (calendarEnhancementRunning) return;
  calendarEnhancementRunning = true;
  try {
    if (!cachedAssignments) cachedAssignments = await loadCanvasAssignments();
    const events = document.querySelectorAll(".fc-day-grid-event.assignment");
    for (const event of events) {
      if (event.dataset.mycalEnhanced === "true") continue;
      const assignment = matchCanvasAssignment(event, cachedAssignments);
      if (!assignment) continue;
      const content = event.querySelector(".fc-content");
      if (!content) continue;
      event.dataset.mycalEnhanced = "true";
      const metadata = (await getSavedMetadata(assignment)) || {};
      if (!event.isConnected) continue;

      // A small edit control exists for EVERY matched assignment, not just saved ones.
      const edit = document.createElement("button");
      edit.type = "button";
      edit.className = "mycal-event-edit";
      edit.textContent = "✎";
      edit.title = "Customize in MyCal";
      edit.setAttribute("aria-label", `Customize ${assignment.name} in MyCal`);
      edit.addEventListener("click", e => {
        e.preventDefault();
        e.stopPropagation();
        openPowerToolEditor(event, assignment, metadata);
      });
      content.appendChild(edit);

      // Only show a priority/time badge if the student has saved a plan.
      const badge = document.createElement("button");
      badge.type = "button";
      badge.className = "power-tool-badge";
      badge.hidden = !metadata.priority || !metadata.estimatedTime;
      const icons = { high: "🔴", medium: "🟡", low: "🟢" };
      if (!badge.hidden) {
        badge.textContent = `${icons[metadata.priority] || ""} ${metadata.priority.toUpperCase()} · ⏱ ${metadata.estimatedTime}`;
      }
      badge.addEventListener("click", e => {
        e.preventDefault();
        e.stopPropagation();
        openPowerToolEditor(event, assignment, metadata);
      });
      content.appendChild(badge);
    }
  } catch (error) {
    console.error("MyCal calendar enhancement failed:", error);
    // Retry API loading on the next calendar update.
    cachedAssignments = null;
  } finally {
    calendarEnhancementRunning = false;
  }
}

function scheduleCalendarEnhancement() {
  clearTimeout(calendarRefreshTimer);
  calendarRefreshTimer = setTimeout(enhanceCalendar, 180);
}

// Canvas dynamically replaces events when navigating months/weeks.
// Watch only calendar changes; avoid reacting to MyCal's own controls.
const calendarObserver = new MutationObserver(mutations => {
  const changedCalendarEvents = mutations.some(m =>
    [...m.addedNodes].some(node => node.nodeType === 1 &&
      (node.matches?.(".fc-day-grid-event.assignment, .fc-day-grid, .fc-view") ||
       node.querySelector?.(".fc-day-grid-event.assignment")))
  );
  if (changedCalendarEvents) scheduleCalendarEnhancement();
});
calendarObserver.observe(document.documentElement, { childList: true, subtree: true });
setTimeout(enhanceCalendar, 2000);
